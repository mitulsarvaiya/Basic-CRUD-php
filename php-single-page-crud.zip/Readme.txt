**** Setting up this project ****
1. Create a database called crud

2. In the crud database, create a table info with the following fields:
-id - int(11)
-name - varchar(100)
-address - varchar(100)
That's it. Have fun!

For more tutorials, don't forget the visit: codewithawa.com 
